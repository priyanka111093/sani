<?php


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>untitled</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.23.1" />
</head>

<body>
	
	<?php
	$a=53;
	$b=33;
	if( $a == $b ) 
	{
	echo "value of a are equal of= $a";
}
else if( $a >$b ) 
{
echo "value of a is bigger=$a";
}
else if($a<=$b)
{
echo "value of b is greater=$b";
}
else
{ 
echo "value of a=$a and it is not equal to value of b=$b";
}
?>
</body>

</html>
