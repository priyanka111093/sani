<?php
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>hello world</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<meta name="generator" content="Geany 1.23.1" />
	<link rel="stylesheet" href="sani.css"/>
	
</head>

<body>
	<?php

 
 echo "Hello with time";
?>

<p>
	<?php  print date('r');
 print "\\n";
 print date('D, d M Y H:i:s T');
 print "\\n";
 ?>
 
</p>
</body>

</html>
